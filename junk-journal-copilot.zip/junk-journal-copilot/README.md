# Junk Journal Copilot

Local-first web app that generates plans for **physical junk journaling** spreads:
transparent tape + washi tape strategies, layering recipe steps, and handwriting prompts.

## Run locally

```bash
npm install
npm run dev
```

Open http://localhost:3000
